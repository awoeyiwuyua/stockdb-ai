# StockDB 0.17.0-r10 候选独立交付与复验报告

- **候选构建版本**：`src+0.17.0+b0b6eeb`（Candidate r10）
- **基线 Commit**：`b0b6eeb1c5e22798004b3c401035780d273a65e7`
- **补丁文件名**：`patch-v0.17.0-r10.patch`
- **补丁 SHA256**：`3e78a82d1b930de0662545e5a296ad5b2b047aa89c62de25eaf066343d2af0d6`
- **服务状态声明**：`service_status = "BLOCKED"`，`joint_status = "not_run"`，`production_routes_changed = false`
- **报告生成时间**：`2026-11-05T15:45:00+08:00`

---

## 一、 R10 核心修复：删除普通持久字典清零后门，全量值严格单调

### 1. 根本问题与根因收敛 (P0)
- **审阅阻断现象**：在 r9 中，虽然修复了并发较大失败被较小正数失败回写退回的缺陷，但在普通持久化字典 `_EmClientStateDict.__setitem__` 中仍遗留了 `elif v <= 0.0:` 和 `elif st <= 0:` 分支，导致任何向持久字典写入 `0.0` 或 `0` 的操作，直接绕过了门控的代际校验（`commit_success`），将已生效的活跃冷却 `cooldown_until` 强制清零或退避阶数 `backoff_streak` 归零。消费方独立两项夹具（`test_zero_cooldown_write_cannot_clear_active_gate` 与 `test_zero_streak_write_cannot_reduce_active_backoff`）全部 FAIL。
- **状态所有权原则终极收口**：
  1. **彻底删除清零后门**：删除了 `_EmClientStateDict.__setitem__` 中的 `elif v <= 0.0:` 与 `elif st <= 0:` 分支；
  2. **活跃保护期对所有输入严格单调**：当门控处于活跃保护期（`gate._state.cooldown_until > now`）时，对传入的任何值（含 `0.0`、负数、过期时间戳或 `0` 阶数），严格执行单调合并：
     - `effective = max(gate._state.cooldown_until, v)`
     - `effective_st = max(gate._state.backoff_streak, st)`
     写入后在持久字典和门控中均保留当前生效的保护值，绝不允许任何形式的降低、缩短或清除；
  3. **清除保护仅由代际验证完成**：解除门控保护严格仅限 `ProviderGate.commit_success(req_gen, client_state)` 在代际完全一致时原子完成，或在生命周期销毁时显式调用 `gate.reset()`；
  4. **测试清理与生产隔离**：测试 `setUp()` 与重置夹具使用显式 `br.EM_GATE.reset()` 与 `dict.__setitem__`，彻底杜绝为测试便利保留生产代码清零后门。

---

## 二、 补丁全量冷却/退避与写入路径权威审查 (State Ownership Audit)

| 写入位置 / 调用点 | 角色分类 | 锁与约束机制 | 为何绝不降级/缩短/清除生效冷却 |
| :--- | :--- | :--- | :--- |
| `ProviderGate.commit_success(gen, client_state)` | **权威受锁解除** (Authoritative Success Commit) | 单一 `gate._lock` 临界区 | 仅当请求在途期间未发生任何新失败（`gen == self._generation`）时原子清零；若代际过时严格拒绝并回写门控当前冷却。 |
| `ProviderGate.record_failure(reason, ...)` | **权威受锁写入** (Authoritative Failure Write) | 单一 `gate._lock` 临界区 | 计算 `max(self._state.cooldown_until, now + cooldown_duration)`，失败退避惩罚严格单调递增并自增代际。 |
| `ProviderGate.sync_cooldown(until, streak)` | **普通单调合并** (Monotonic Merge) | 单一 `gate._lock` 临界区 | 仅当 `until > self._state.cooldown_until and until > now` 时才允许向上同步，只增不减。 |
| `ProviderGate.reset()` | **显式生命周期重置** (Explicit Reset) | 单一 `gate._lock` 临界区 | 仅在测试隔离重置或进程生命周期重置时显式调用，创建全新状态并递增代际。 |
| `_EmClientStateDict.__setitem__("cooldown_until")` | **普通单调合并** (Strict Monotonic Merge) | 获取 `gate._lock` 临界区 | 活跃保护期（`> now`）对所有输入（正数/0/负数）均执行 `effective = max(gate._state.cooldown_until, v)`，普通写入绝不缩短或清除门控。 |
| `_EmClientStateDict.__setitem__("backoff_streak")` | **普通单调合并** (Strict Monotonic Merge) | 获取 `gate._lock` 临界区 | 活跃保护期（`> now`）对所有输入（正数/0/负数）均执行 `effective_st = max(gate._state.backoff_streak, st)`，连败阶数绝不被普通写入倒退。 |
| `_em_enter_cooldown(reason, drop_class)` | **受控失败流** (Controlled Failure Flow) | 结合 gate 锁读取有效快照 | 写入后持锁重读门控 `effective_until` 与 `effective_streak`，返回值与落盘一致反映有效快照。 |
| `_em_client_state()` 磁盘恢复 | **受控恢复** (Controlled Recovery) | `_EmClientStateDict` 封装 | 磁盘加载后由 `__getitem__` 与 `__setitem__` 双向保护，旧磁盘文件冷启动绝不擦除内存门控新冷却。 |

---

## 三、 绑定当前精确补丁的可审阅构建/部署/回退计划（严格仅准备，不执行）

> [!IMPORTANT]
> 遵循 standing red lines 纪律：本计划仅作为候选交付与后续用户部署审阅的前置技术准备，在未获用户明确批准前，**不执行构建、不部署上线、不重启容器、不修改生产卷、不切换路由**。

### 1. 目标服务与构建身份
- **目标服务容器**：`stockdb-ai`（包含 Web 8000 端口服务、MCP HTTP `/mcp` 端点及 stdio 模式）；
- **基线源码 Commit**：`b0b6eeb1c5e22798004b3c401035780d273a65e7`；
- **精确应用补丁**：`patch-v0.17.0-r10.patch`（SHA256: `3e78a82d1b930de0662545e5a296ad5b2b047aa89c62de25eaf066343d2af0d6`）；
- **目标运行时构建版本标识**：`src+0.17.0+b0b6eeb`（Candidate r10）。

### 2. 旧镜像保留与数据备份策略
- **旧镜像保留**：在构建新镜像前，对当前正在运行的容器镜像打保留标签：
  `docker tag stockdb-ai:latest stockdb-ai:backup-pre-0.17.0-r10`
- **数据卷快照/备份**：在部署前，对板块缓存持久化卷（`/data/cache/board/`）创建原子备份：
  `cp -a /data/cache/board /data/cache/board_backup_pre_r10`
  若需回退，可完整还原所有板块缓存，且支持运行 `run_rollback_rehearsal.py` 验证数据 100% 逐 bit 还原。

### 3. 启动与健康检查判据
- **优雅启动顺序**：
  1. `market_v3.HEALTH.start()` 启动健康巡检（单线程原子启动）；
  2. 若 `BOARD_BACKFILL_ENABLED=True`，启动 `board_reliability.WORKER.start()`；
  3. `_BoundedHTTPServer` 执行端口 bind 与 serve，若发生 bind 失败（如 `OSError: [Errno 98] Address already in use`），`finally` 块确定性执行 `br.WORKER.stop()` 与 `v3.HEALTH.stop()` 清理，无遗留僵尸线程。
- **健康验收判据**：
  - HTTP `GET /health` 返回 200 OK，包含 `market_v3` 正常状态；
  - HTTP `POST /mcp` 工具列表探活成功；
  - 板块 worker `get_state()` 报告 `running: true, stopping: false, thread_alive: true`。

### 4. 故障检测与回退触发判据
- **回退触发条件**：
  - 容器启动后 30 秒内出现端口 bind 异常或崩溃重启；
  - 提供者闸门状态出现非单调倒退或异常降级；
  - 遇到无法恢复的缓存损坏且 `.bak` 回退失败；
- **确定性回退步骤**：
  1. 停止运行中容器：`docker stop stockdb-ai`；
  2. 使用保留的旧镜像重新运行：`docker run ... stockdb-ai:backup-pre-0.17.0-r10`；
  3. 若缓存结构损坏，执行卷恢复：`rm -rf /data/cache/board && cp -a /data/cache/board_backup_pre_r10 /data/cache/board`；
  4. 源码工作区如需回滚，直接执行反向补丁：`git apply --reverse patch-v0.17.0-r10.patch`（已通过 100% 干净回退验证）。

---

## 四、 测试验证全景与确定性证据

1. **消费方回归扩展套件 (`test_consumer_negative_regressions.py`)**：
   - 28 个测试方法全部 **PASS**（0.58s）。
   - 包含消费方 13 项原反例、2 项原子性用例、9 项生命周期扩展用例、2 项失败回写用例，以及本轮新增的：
     - `test_consumer_27_zero_cooldown_write_cannot_clear_active_gate`：验证普通写入 `0.0` 无法清除生效冷却（`in_cooldown=true` 稳固保持）；
     - `test_consumer_28_zero_streak_write_cannot_reduce_active_backoff`：验证普通写入 `0` 无法降低生效退避连败阶数（`backoff_streak=2` 稳固保持）。
   - 观测材料：
     - `evidence/consumer_observations/ordinary-zero-cooldown.json`（`in_cooldown: true`, `cooldown_remaining_s: 1799`）
     - `evidence/consumer_observations/ordinary-zero-streak.json`（`backoff_streak: 2`, `in_cooldown: true`）
2. **核心三组回归套件**：
   - 板块可靠性 (`test_board_reliability_v1.py`): 38 / 38 **PASS**；
   - Market V3 核心 (`test_market_v3.py`): 101 运行，99 **PASS**, 2 SKIP, 0 FAIL；
   - Market V3 Research (`test_market_v3_research.py`): 59 / 59 **PASS**；
   - **合计 198 运行：196 PASS, 2 SKIP, 0 FAIL**。
3. **隔离回退演练 (`run_rollback_rehearsal.py`)**：
   - 真实数据结构转换与回退演练，回退后 SHA-256：`31c38ddca7c47b4db160682c3659c88971725d82290fa1e89dfcefd23e47ca7c`，100% 逐 bit 一致。
4. **历史引用与本轮身份明确界定 (C14)**：
   - `evidence/c14_worker_lifecycle_passive_probe.json` 中明确记录 `historical_reference_at` 为 13:36 历史静态对照，本轮以测试模拟时钟/tick 进行确定性验证（`verified_at = "2026-11-05T15:45:00+08:00"`），并说明 NAS 在线常驻 daemon 需待真实部署后运行。

---

## 五、 未执行项与授权边界

- C19（13 板块 500 日在线覆盖）：BLOCKED（未获线上部署授权）；
- C20（在线性能与缓存穿透）：BLOCKED（未获线上部署授权）；
- C21（生产镜像与环境交付）：BLOCKED（未获线上部署授权）；
- C23（7 日稳定性观察）：NOT_RUN；
- 坚持三不原则，绝不私自重启容器、不部署上线、不修改生产卷、不切换路由、不自动 commit/push/merge。
