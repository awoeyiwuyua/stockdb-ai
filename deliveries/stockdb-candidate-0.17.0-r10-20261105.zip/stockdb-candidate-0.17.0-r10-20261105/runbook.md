# StockDB 0.17.0-r10 离线校验与回退演练 Runbook

## 1. 补丁应用与反向预检
```powershell
# 验证补丁反向应用干净恢复声明基线 b0b6eeb1c5e22798004b3c401035780d273a65e7
git apply --check --reverse patch-v0.17.0-r10.patch

# 验证补丁正向应用
git apply --check patch-v0.17.0-r10.patch
```

## 2. 独立套件离线回归验证
```powershell
# 消费方 28 项反例与扩展测试（包含 r8/r9/r10 失败回写、交错测试与普通零值回写防穿透测试）
python -m unittest stockdb-ai/interfaces/mcp/test_consumer_negative_regressions.py

# 核心三组基线回归套件（198 测试：196 PASS, 2 SKIP, 0 FAIL）
python -m unittest discover -s stockdb-ai/interfaces/mcp -p "test_board_reliability_v1.py"
python -m unittest discover -s stockdb-ai/interfaces/mcp -p "test_market_v3.py"
python -m unittest discover -s stockdb-ai/interfaces/mcp -p "test_market_v3_research.py"
```

## 3. 隔离回退演练
```powershell
python stockdb-ai/evidence/run_rollback_rehearsal.py
```

## 4. 消费方合同校验器验证
```powershell
# 验证包完整性（预期退出码 0: OK）
python C:/Users/75393/Desktop/mingli/docs/contracts/stockdb-board-reliability-v1/validate_return.py --verify-package stockdb-candidate-0.17.0-r10-20261105

# 验证离线报告声明 (预期退出码 2: PENDING，保持线上项未执行诚实上报)
python C:/Users/75393/Desktop/mingli/docs/contracts/stockdb-board-reliability-v1/validate_return.py --report stockdb-candidate-0.17.0-r10-20261105/report.json --evidence-root stockdb-candidate-0.17.0-r10-20261105
```
