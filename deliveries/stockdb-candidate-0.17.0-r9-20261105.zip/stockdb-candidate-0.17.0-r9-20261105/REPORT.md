# StockDB 0.17.0-r9 候选独立交付与复验报告

- **候选构建版本**：`src+0.17.0+b0b6eeb`（Candidate r9）
- **基线 Commit**：`b0b6eeb1c5e22798004b3c401035780d273a65e7`
- **补丁文件名**：`patch-v0.17.0-r9.patch`
- **补丁 SHA256**：`bd17e3b401ba50796f5fad0c746d23faa46fd8784d20941e3a4e556b26d79bfe`
- **服务状态声明**：`service_status = "BLOCKED"`，`joint_status = "not_run"`，`production_routes_changed = false`
- **报告生成时间**：`2026-11-05T15:20:00+08:00`

---

## 一、 R9 核心修复：失败回写与冷却状态所有权单调收口

### 1. 根本问题与根因收敛 (P0)
- **审阅阻断现象**：在并发或交错失败场景中，失败 A 由门控生成 30 分钟冷却（`until_A`）；在 A 执行持久化回写前，并发失败 B 生成了更长的 60 分钟冷却（`until_B`）；随后失败 A 调用 `state["cooldown_until"] = until_A`，`_EmClientStateDict` setter 缺乏对生效保护的单调性约束，无条件将门控已生效的 60 分钟冷却退回 30 分钟。
- **状态所有权原则收口**：
  1. **Gate 唯一权威所有者**：`ProviderGate`（`EM_GATE`/`THS_GATE`）为冷却与退避惩罚的唯一权威所有者；
  2. **普通字典单调合并**：`_EmClientStateDict.__setitem__` 在门控处于活跃冷却期内（`gate._state.cooldown_until > now`）执行写入时，严格执行单调合并 `effective = max(gate._state.cooldown_until, v)`，绝不允许过时或较短的值缩短生效冷却；
  3. **受控失败流生成有效快照**：`_em_enter_cooldown` 在调用 `record_failure` 之后，直接从门控持锁读取当前生效快照 `effective_until` 与 `effective_streak`，确保诊断、返回值与落盘状态均反映权威生效状态，消除过时本地变量穿透；
  4. **解除保护仅由代际验证完成**：解除冷却（清零）严格仅限 `ProviderGate.commit_success` 在代际一致时原子完成，普通持久字典回写无法绕过门控解除保护。

---

## 二、 补丁全量冷却/退避与写入路径权威审查 (Requirement 3)

| 写入位置 / 调用点 | 角色分类 | 锁与约束机制 | 为何绝不降级/缩短生效冷却 |
| :--- | :--- | :--- | :--- |
| `ProviderGate.commit_success(gen, client_state)` | **权威写入** (Authoritative Write) | 单一 `gate._lock` 临界区 | 仅当请求在途期间未发生任何新失败（`gen == self._generation`）时才允许清零；若代际过时严格拒绝并回写门控当前冷却。 |
| `ProviderGate.record_failure(reason, ...)` | **权威写入** (Authoritative Write) | 单一 `gate._lock` 临界区 | 计算 `max(self._state.cooldown_until, now + cooldown_duration)`，失败退避惩罚严格单调递增并自增代际。 |
| `ProviderGate.sync_cooldown(until, streak)` | **普通合并** (Monotonic Merge) | 单一 `gate._lock` 临界区 | 仅当 `until > self._state.cooldown_until and until > now` 时才允许向上同步，只增不减。 |
| `ProviderGate.reset()` | **显式重置** (Authoritative Reset) | 单一 `gate._lock` 临界区 | 仅在测试清理或进程生命周期重置时显式调用，创建全新状态并递增代际。 |
| `_EmClientStateDict.__setitem__("cooldown_until")` | **普通合并** (Monotonic Merge) | 获取 `gate._lock` 临界区 | 门控冷却期内（`> now`）严格 `effective = max(gate._state.cooldown_until, v)`，旧写入绝不降级门控。 |
| `_EmClientStateDict.__setitem__("backoff_streak")` | **普通合并** (Monotonic Merge) | 获取 `gate._lock` 临界区 | 门控冷却期内严格 `effective_st = max(gate._state.backoff_streak, st)`，连败计数不被旧值倒退。 |
| `_em_enter_cooldown(reason, drop_class)` | **受控失败流** (Controlled Failure Flow) | 结合 gate 锁读取有效快照 | 写入后重读门控 `effective_until` 与 `effective_streak`，返回值与落盘一致反映有效快照。 |
| `_em_client_state()` 磁盘恢复 | **受控恢复** (Controlled Recovery) | `_EmClientStateDict` 封装 | 磁盘加载后由 `__getitem__` 与 `__setitem__` 双向保护，旧磁盘文件冷启动绝不擦除内存门控新冷却。 |

---

## 三、 测试验证全景与确定性证据

1. **消费方回归扩展套件 (`test_consumer_negative_regressions.py`)**：
   - 26 个测试方法全部 **PASS**（0.58s）。
   - 包含消费方 13 项原反例、2 项原子性用例、9 项生命周期扩展用例，以及本轮新增的：
     - `test_consumer_25_older_failure_writeback_preserves_newer_longer_cooldown`：精确复现并闭环消费方独立夹具；
     - `test_consumer_26_success_and_failure_interleaved_preserves_active_cooldown`：成功与失败交错并发确定性验证。
   - 观测材料：`evidence/consumer_observations/failure-writeback-cooldown.json`（60 分钟冷却稳固维持，未被 30 分钟旧回写退回）与 `success-failure-interleaved.json`。
2. **核心三组回归套件**：
   - 板块可靠性 (`test_board_reliability_v1.py`): 38 / 38 **PASS**；
   - Market V3 核心 (`test_market_v3.py`): 101 运行，99 **PASS**, 2 SKIP, 0 FAIL；
   - Market V3 Research (`test_market_v3_research.py`): 59 / 59 **PASS**；
   - **合计 198 运行：196 PASS, 2 SKIP, 0 FAIL**。
3. **隔离回退演练 (`run_rollback_rehearsal.py`)**：
   - 真实数据结构转换与回退演练，回退后 SHA-256：`31c38ddca7c47b4db160682c3659c88971725d82290fa1e89dfcefd23e47ca7c`，100% 逐 bit 一致。
4. **历史引用与本轮身份明确界定 (C14)**：
   - `evidence/c14_worker_lifecycle_passive_probe.json` 中保留 `historical_reference_at` 作为 13:36 历史观测对照，同时记录 `verified_at = "2026-11-05T15:19:00+08:00"` 与本轮 26 项运行证据，明确区分历史材料与本次新运行。

---

## 四、 未执行项与授权边界

- C19（13 板块 500 日在线覆盖）：BLOCKED（未获线上部署授权）；
- C20（在线性能与缓存穿透）：BLOCKED（未获线上部署授权）；
- C21（生产镜像与环境交付）：BLOCKED（未获线上部署授权）；
- C23（7 日稳定性观察）：NOT_RUN；
- 坚持三不原则，绝不私自重启容器、不部署上线、不修改生产卷、不切换路由、不自动 commit/push/merge。
