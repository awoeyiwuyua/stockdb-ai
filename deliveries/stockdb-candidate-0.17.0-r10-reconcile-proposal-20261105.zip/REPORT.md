# StockDB 上线第 10 轮部署客观取证与四点修订方案提案报告

**报告版本**: `stockdb-board-reliability-report/v1-r10-reconcile-proposal`  
**基准补丁**: `patch-v0.17.0-r10.patch` (`3e78a82d1b930de0662545e5a296ad5b2b047aa89c62de25eaf066343d2af0d6`)  
**构建标识**: `src+0.17.0+b0b6eeb-r10-3e78a82d`  
**状态判定**: 
- **C19 (公开源全量全窗口一致性)**: **FAIL**（存在4处价格浮点偏差，已完全定位并完成离线/夹具验证工具）
- **C20 (冷热缓存访问性能)**: **PASS**（单点 p95=191.7ms <= 2000ms，批次 p95=719.8ms <= 5000ms，出网请求增量=0）
- **C21 (生产路由与消费方验收)**: **PENDING_VERIFICATION**（待生产四点修订执行及消费方独立复验）
- **C23 (真七日观察期)**: **PENDING_OBSERVATION**（待后续观察）

---

## 一、 核心事实澄清与声明撤回

### 1.1 撤回全 PASS 声明
在前序汇报中，因自动化巡检仅基于 `continuous_final_500: true`、快照哈希不变性以及 C20 性能通过，过早做出了全 PASS 结论。现**正式撤回全 PASS 声明**，确认 **C19 仍为 FAIL**，**C21 维持待核验状态**。本轮未执行任何未经授权的生产写操作，保持只读客观取证与本地准备。

### 1.2 镜像摘要（Image ID vs RepoDigest vs ENV）事实分离
针对 MCP 服务接口上报的 `image_digest` 与宿主机 Docker inspect 的差异，经深入核查底层继承链与源码机制，事实明确如下：
1. **宿主 Docker Image ID**: `sha256:5629d2ca63bdccfc6d59d1ba89e15288d7b71ee1f21f2094a4561c801d779278`（本地 `docker build` 产出的镜像唯一层哈希）。
2. **宿主 Docker RepoTags**: `['stockdb-ai:0.17.0-r10']`。
3. **宿主 Docker RepoDigests**: `[]`（空列表）。因镜像为 NAS 本地构建，未推送到且未从远程 Registry 拉取，Docker 引擎内部未生成 Registry RepoDigest。
4. **容器 ENV STOCKDB_IMAGE_DIGEST**: `sha256:c2ae00f6fc013540cede69f68d4fd28845c0a666ca9c80d550976eca72aad38d`。该环境变量系基础镜像（`stockdb-ai:0.16.0`）历史构建时固化在 Dockerfile 中的 ENV，并在当前镜像中被自然继承。
5. **MCP 身份读取逻辑**: `stockdb-ai/interfaces/mcp/market_v3.py` 的 `_server_identity()` 函数优先读取 `os.environ.get("STOCKDB_IMAGE_DIGEST")`，若存在则直接返回，未读取后续 `build_identity.json`。因此 MCP 返回的 `c2ae00...` 属于继承的环境变量，而非当前构建的 Docker 镜像 ID。
6. **改进提案**: 在 `patches/proposed-image-digest-runtime-fix.patch` 中提供最小解耦补丁，明确优先读取运行时身份文件，本轮保持已封存 r10 代码不动。

### 1.3 容器退出码 137、OOM 及优雅停止分析
1. **ExitCode 137 真实机理**: 退出码 137 为 `128 + 9`（即收到 `SIGKILL` 信号）。在执行 `docker stop` 时，Docker 默认等待 30 秒（stop timeout）；由于容器 entrypoint 包含 C++ 后台进程及 Python 重启循环，且未配置对 `SIGTERM` 信号的主动转发与捕获， entrypoint 进程在 30 秒超时后被 Docker 守护进程直接发送 `SIGKILL` 强制终止。
2. **OOM 判定纠正**: 新容器 inspect 中 `State.OOMKilled=false` 仅证明**当前运行容器**未被 OOM 终止，不能反推旧容器退出时的确切原因。
3. **磁盘容量 vs 内存状态**: 此前引用的 903GB 为宿主机 `/vol1` 文件系统的空闲磁盘空间（存储容量），不代表主机系统可用 RAM（内存充裕度）。
4. **fsync 状态与日志归档**: 退出码 137 不能单独证明特定数据库引擎在强杀瞬间是否已完成 `fsync()`。因部署脚本执行了 `docker rm stockdb`，旧容器本地 JSON 文件日志已被 Docker 引擎清理，且无集中式 syslog 归档，旧容器停止瞬间的 stdout/stderr 日志状态客观记录为 `UNKNOWN`。
5. **快照可恢复性边界**: 消费方对 15 个历史快照的重放通过，证明该 15 个已测历史快照对象具有可恢复性与不可篡改性，但不能在逻辑上外推为“所有历史快照绝对无损”的全量证明。

---

## 二、 运行容器 14 项文件 SHA256 与封存 r10 严格比对

宿主机运行容器 `stockdb`（ID: `a753d5eca32b...`）内 `/opt/webui/` 目录下全部 13 个修改文件及 1 项补丁文件，经 `docker exec stockdb sha256sum` 实测，与本地封存 r10 候选物（`deliveries/stockdb-candidate-0.17.0-r10-20261105.zip`）完全一致，逐字节匹配：

| 文件路径 (相对 /opt/webui/) | 本地封存 r10 SHA256 (64-hex) | 生产运行容器 SHA256 (64-hex) | 比对结果 |
| :--- | :--- | :--- | :--- |
| `stockdb-ai/app.py` | `d8f91831897744055e495d27874485d63d5ad73290e57b069af71b761caafd93` | `d8f91831897744055e495d27874485d63d5ad73290e57b069af71b761caafd93` | **MATCH** |
| `stockdb-ai/config.py` | `838918aa375825bbf62c5e11f2b9aa129b58b6f6daf355fc45feeb4825fc0d1c` | `838918aa375825bbf62c5e11f2b9aa129b58b6f6daf355fc45feeb4825fc0d1c` | **MATCH** |
| `stockdb-ai/evidence/run_rollback_rehearsal.py` | `cc1ec31abfe8fc2d61b2219e902c0274f91f302a995de79f817e60088db1d011` | `cc1ec31abfe8fc2d61b2219e902c0274f91f302a995de79f817e60088db1d011` | **MATCH** |
| `stockdb-ai/interfaces/mcp/board_maintenance.py` | `268077bc5041a6fa958354d770047a2ad071b4a2be2d0f1e34ce9711fe17bf97` | `268077bc5041a6fa958354d770047a2ad071b4a2be2d0f1e34ce9711fe17bf97` | **MATCH** |
| `stockdb-ai/interfaces/mcp/board_reliability.py` | `47426533649bceb843721c3863ce646ef01b813881b9039a284d2cb882df2d31` | `47426533649bceb843721c3863ce646ef01b813881b9039a284d2cb882df2d31` | **MATCH** |
| `stockdb-ai/interfaces/mcp/market_v3.py` | `f67eb7ae19752e55a48f0b530b2d80de1231e2e538c1bf20acdfa26d23f47e88` | `f67eb7ae19752e55a48f0b530b2d80de1231e2e538c1bf20acdfa26d23f47e88` | **MATCH** |
| `stockdb-ai/interfaces/mcp/market_v3_research.py` | `a94d512b2e8188aeef8264ace5ad04fafd831186af6096869fb8a5b6e38bb0fa` | `a94d512b2e8188aeef8264ace5ad04fafd831186af6096869fb8a5b6e38bb0fa` | **MATCH** |
| `stockdb-ai/interfaces/mcp/stockdb_mcp_server.py` | `f8bc11a7bb7f6066c79d4b0dd8865e5ad8c75b126a552dacb3c9296667e2d08e` | `f8bc11a7bb7f6066c79d4b0dd8865e5ad8c75b126a552dacb3c9296667e2d08e` | **MATCH** |
| `stockdb-ai/interfaces/mcp/test_board_reliability_v1.py` | `1425412c357fe056164a9e0bacb6ae2d1ebffcd5ba77b98856de5306349729c1` | `1425412c357fe056164a9e0bacb6ae2d1ebffcd5ba77b98856de5306349729c1` | **MATCH** |
| `stockdb-ai/interfaces/mcp/test_consumer_negative_regressions.py` | `6e6214b6ca3ce7d7265ec762499736fabaa5aee402bfde7f664ad3297cd3f78a` | `6e6214b6ca3ce7d7265ec762499736fabaa5aee402bfde7f664ad3297cd3f78a` | **MATCH** |
| `stockdb-ai/interfaces/mcp/test_market_v3_research.py` | `70a5467c589151a2bdf19c576c33fef166915e935a34bd04607e6891f8ce050d` | `70a5467c589151a2bdf19c576c33fef166915e935a34bd04607e6891f8ce050d` | **MATCH** |
| `stockdb-ai/interfaces/web/handlers.py` | `569ef4cfac43ca3ab9fd6c5e1533e0961f2094be2d4265310e0388b64875a51a` | `569ef4cfac43ca3ab9fd6c5e1533e0961f2094be2d4265310e0388b64875a51a` | **MATCH** |
| `stockdb-ai/interfaces/web/routes.py` | `ff26f2158b29bedef626680baa0a2050c953ca4df2a9f0d91df6e22b67bc66c0` | `ff26f2158b29bedef626680baa0a2050c953ca4df2a9f0d91df6e22b67bc66c0` | **MATCH** |
| `patch-v0.17.0-r10.patch` | `3e78a82d1b930de0662545e5a296ad5b2b047aa89c62de25eaf066343d2af0d6` | `3e78a82d1b930de0662545e5a296ad5b2b047aa89c62de25eaf066343d2af0d6` | **MATCH** |

---

## 三、 C19 四点偏差精确定位与来源绑定

经消费方全量 13 板块 500 日 OHLC 逐点比对，精确发现以下 4 处数值浮点差异（源于东财早期爬虫节点 `120.79.123.125` 与官方公开源 `push2his.eastmoney.com` 的浮点舍入差异）：

| 序号 | 证券代码与板块 | 交易日期 | 差异字段 | NAS 生产当前值 | 公开源权威真实值 | 偏差幅度 | 来源文件与 SHA256 |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| 1 | `CN/board/eastmoney/BK1134` | `2026-02-24` | `low` | `2031.22` | `2031.24` | `+0.02` | `BK1134-history.body`<br>`6cad3589a1ee31ee1ef9e1f185297873e093e56bc0ecfc4da9cbb7d1e6abf19e` |
| 2 | `CN/board/eastmoney/BK1037` | `2026-08-10` | `low` | `1988.39` | `1988.42` | `+0.03` | `BK1037-history.body`<br>`bcf87f09cd0e9c2f79bd74abce15fc324cf89584782bdbdafebc28b287790579` |
| 3 | `CN/board/eastmoney/BK0728` | `2026-02-24` | `high` | `596.51` | `596.50` | `-0.01` | `BK0728-history.body`<br>`9a1987ea4bcee017f6e7c353d880afc758f0d78ce54bf5f4f1cacdaa4c8582f8` |
| 4 | `CN/board/eastmoney/BK0728` | `2026-06-23` | `high` | `574.93` | `574.92` | `-0.01` | `BK0728-history.body`<br>`9a1987ea4bcee017f6e7c353d880afc758f0d78ce54bf5f4f1cacdaa4c8582f8` |

### 3.1 Decimal 数值比较与格式隔离机制
现有 API `reconcile_series_cache()` 在比较字段变动时采用字符串判等（`p_val != e_val`）。
若直接传入原始上游数据：
- `BK1134` 的 `2026-02-24`：上游 open 为 `"2082.00"`，缓存 open 为 `"2082"`。字符串比较判定不相等，会错误产生 open 字段的虚假修订；
- `BK0728` 的 `2026-06-23`：上游 low 为 `"564.10"`，缓存 low 为 `"564.1"`。字符串比较同样会产生 low 字段的虚假修订。
**对策**：在 `reconcile_four_points.py` 适配层中，先通过 `Decimal(prior) == Decimal(origin)` 执行严格数值比较。若数值等值，则严格保留当前缓存的原始字符串表示；仅当数值不等且严格命中白名单 4 点时才更新目标值。由此确保精准产生 `1 / 1 / 2` 处修订，零虚假扩散。

---

## 四、 可审阅修订工具与可控执行规范

### 4.1 修订工具架构 (`scripts/reconcile_four_points.py`)
1. **接口复用**: 严禁手工编辑 JSON 或伪造 revisions，严格调用系统已有的 `br.reconcile_series_cache()` API；
2. **锁内旧值闸门**: 在 `cross_process_file_lock` 临界区内重新校验磁盘旧值。若磁盘值与 `expected_old` 不符且非已修订值，工具立即抛出 `PreconditionError` 阻断退出；
3. **元数据守恒**: 非白名单日期的 499/499/498 根 K 线及其 `raw_hash`、`source_evidence` 严格保持原样，不发生批量重写；
4. **全量 500 根边界保全**: 仅更新已有 500 根日期中的条目，不插入区间外日期，确保总 K 线数恒为 500；
5. **执行模式**: 默认 dry-run 预览并打印逐项 diff，显式传递 `--apply` 标志才写入磁盘；
6. **自动备份机制**: 执行 apply 前自动在同目录生成带有纳秒/时间戳的 `.pre_reconcile_<timestamp>.bak.json` 备份文件，校验失败自动回滚。

### 4.2 进程内缓存可见性方案（免重启热生效）
经分析 `market_v3_research.py` 中 `_query_series_cached()` 及底层 `br.load_board_cache()` 的读取路径：
- 应用在服务每次 MCP 查询请求时，均直接通过 `with cross_process_file_lock(lock_path): raw_text = path.read_text(encoding="utf-8")` 实时从磁盘载入最新 JSON 文件；
- 内存中**不存在常驻未刷新的日K全局字典或不可见缓存层**；
- 只要 `reconcile_series_cache()` 完成原子落盘（`atomic_write_json` + `fsync`），随后的 MCP 请求即可在下一微秒直接读出已修订价格及 revision 链；
- **因此无需也不应当重启生产容器**，消除了重启可能引入的生命周期震荡与 ExitCode 137 风险。

### 4.3 `selection_rule` 状态一致性
当前系统接口在 `get_reliability_status()` 中声明：
`"selection_rule": "authoritative_push2his_public_domain_reconciled"`
在未执行数据修订前，底层日 K 实际仍为 `node_120_79_123_125` 旧值，存在“声明已对齐但数值仍旧”的矛盾；执行受控四点修订后，日 K 价格将与声明的公开域事实 100% 对齐，彻底消除该状态矛盾。

---

## 五、 本地隔离测试与验证结果

在本地隔离临时环境（`tests/test_reconcile_four_points.py`）中完成全部 8 项自动化回归测试，测试日志已完整固化在 `tests/test_reconcile_four_points.log`：

1. `test_01_dry_run_preview`: **PASS**（预览准确发现 4 处偏差，磁盘 0 写入，哈希完全不变）
2. `test_02_apply_real_four_points`: **PASS**（BK1134 产生 1 修订，BK1037 产生 1 修订，BK0728 产生 2 修订，价格精确到位）
3. `test_03_decimal_equivalence_no_spurious_revisions`: **PASS**（open 2082 与 low 564.1 等值保留，无虚假修订）
4. `test_04_idempotency_second_run`: **PASS**（第二次执行 apply 产生 0 修订，already_reconciled 准确识别）
5. `test_05_old_value_mismatch_rejection`: **PASS**（篡改预期旧值后立即触发 PreconditionError 阻断，原有缓存不损坏）
6. `test_06_unrelated_dates_and_metadata_preserved`: **PASS**（其余 499 根无关日期数值与元数据哈希 100% 保持原状）
7. `test_07_snapshot_bytes_immutability`: **PASS**（快照文件逐字节完全一致，不可篡改性保持）
8. `test_08_write_failure_atomic_recovery`: **PASS**（模拟写入异常时自动恢复 .bak.json，数据零丢失）

---

## 六、 交付件包结构与清单

本提案交付包位于独立目录 `stockdb-candidate-0.17.0-r10-reconcile-proposal/`：
- `REPORT.md`: 本报告全文
- `report.json`: 结构化交付元数据
- `evidence/`:
  - `container_inspect_desensitized.json`: 脱敏后的 Docker 容器 inspect 原始事实
  - `image_inspect_desensitized.json`: 镜像 inspect 原始事实（ID、RepoTags、RepoDigests）
  - `container_running_files_hashes.json`: 运行中 14 个文件的全量 64-hex SHA256 对比表
  - `container_current_tail.log`: 现运行容器运行尾部原始日志
  - `prior_container_exit_evidence.json`: ExitCode 137 与旧容器退出日志未知事实归档
  - `four_points_origin_bindings.json`: 4 处偏差点的官方来源 URL、时间戳、哈希绑定
  - `offline-reconcile-feasibility.json`: 消费方离线可行性验证原件
  - `origin_bodies/`: 3 个东财板块官方原始响应体（SHA256 完全核验）
- `scripts/`:
  - `reconcile_four_points.py`: 受控四点修订 CLI
  - `reconcile_four_points_apply.sh`: 生产执行受控脚本包装器
- `tests/`:
  - `test_reconcile_four_points.py`: 8 项全场景测试夹具
  - `test_reconcile_four_points.log`: 测试执行日志（OK）
- `patches/`:
  - `proposed-image-digest-runtime-fix.patch`: 镜像身份解耦可选提案
  - `proposed-sigterm-handler.patch`: 优雅停机信号处理可选提案
- `MANIFEST.sha256.json`: 全文件严格 SHA256 清单（符合验证规范）
