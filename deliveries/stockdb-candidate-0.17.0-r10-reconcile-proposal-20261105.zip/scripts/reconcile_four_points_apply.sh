#!/bin/sh
set -eu

# reconcile_four_points_apply.sh
# Safely executes the 4-point C19 reconciliation inside Docker container or on host.

CACHE_DIR="${CACHE_DIR:-/data/market_v3_snapshots/board_daily_cache}"
ORIGIN_DIR="${ORIGIN_DIR:-/data/origin-full}"

echo "=== StockDB 4-Point C19 Reconciliation Executor ==="
echo "Cache Directory:  ${CACHE_DIR}"
echo "Origin Directory: ${ORIGIN_DIR}"
echo ""

# 1. First run dry-run preview
echo "[Step 1] Running dry-run validation..."
python3 /opt/webui/scripts/reconcile_four_points.py \
    --cache-dir "${CACHE_DIR}" \
    --origin-dir "${ORIGIN_DIR}"

# 2. Check if --apply was passed to shell script
if [ "${1:-}" = "--apply" ]; then
    echo ""
    echo "[Step 2] Executing atomic apply with backup..."
    python3 /opt/webui/scripts/reconcile_four_points.py \
        --cache-dir "${CACHE_DIR}" \
        --origin-dir "${ORIGIN_DIR}" \
        --apply
    echo ""
    echo "[Step 3] Verifying idempotency..."
    python3 /opt/webui/scripts/reconcile_four_points.py \
        --cache-dir "${CACHE_DIR}" \
        --origin-dir "${ORIGIN_DIR}" \
        --apply
    echo ""
    echo "=== RECONCILIATION COMPLETED SUCCESSFULLY ==="
else
    echo ""
    echo "Pass '--apply' as argument to commit changes to disk."
fi
