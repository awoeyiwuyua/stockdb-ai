#!/usr/bin/env python3
"""test_reconcile_four_points.py - Acceptance Test Suite for 4-Point C19 Reconciliation

Verifies:
1. Dry-run preview produces exact diffs without disk mutations;
2. Apply mode produces exactly 1 / 1 / 2 revisions across the 3 target series;
3. Decimal equivalence suppresses spurious formatting revisions (e.g. 2082 vs 2082.00, 564.1 vs 564.10);
4. Idempotency: second apply execution produces 0 revisions;
5. Old-value precondition gate: unexpected prior value triggers immediate abort without corruption;
6. Unrelated dates (499 / 499 / 498) and metadata remain strictly immutable;
7. Total bar count remains strictly 500 (no dates added or removed);
8. Snapshot files remain 100% byte-for-byte immutable;
9. Rollback and backup verification: .bak.json preserves prior state on simulated error.
"""

from __future__ import annotations

from decimal import Decimal
import hashlib
import json
from pathlib import Path
import shutil
import sys
import tempfile
import unittest

# Path setup
REPO_ROOT = Path(__file__).resolve().parent.parent.parent
STOCKDB_AI_DIR = REPO_ROOT / "stockdb-ai"
if str(STOCKDB_AI_DIR) not in sys.path:
    sys.path.insert(0, str(STOCKDB_AI_DIR))

PROPOSAL_DIR = REPO_ROOT / "stockdb-candidate-0.17.0-r10-reconcile-proposal"
SCRIPTS_DIR = PROPOSAL_DIR / "scripts"
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))

import interfaces.mcp.board_reliability as br
import reconcile_four_points as rfp


class TestReconcileFourPoints(unittest.TestCase):
    def setUp(self):
        self.tmp_dir = tempfile.TemporaryDirectory()
        self.root_p = Path(self.tmp_dir.name)
        self.cache_dir = self.root_p / "board_daily_cache"
        self.cache_dir.mkdir(parents=True)
        self.snapshots_dir = self.root_p / "snapshots"
        self.snapshots_dir.mkdir(parents=True)

        self.origin_dir = PROPOSAL_DIR / "evidence" / "origin_bodies"
        if not (self.origin_dir / "BK1134-history.body").exists():
            self.origin_dir = Path("C:/Users/75393/Desktop/mingli/tmp/stockdb-r10-live-20261105/origin-full")

        # Copy initial base cache from stockdb_v3_snapshots
        base_cache_src = REPO_ROOT / "stockdb_v3_snapshots" / "board_daily_cache"
        for key in rfp.WHITELIST_TARGETS:
            safe = key.replace("/", "_")
            src = base_cache_src / f"{safe}.json"
            dst = self.cache_dir / f"{safe}.json"
            shutil.copy2(src, dst)
            # Ensure starting state has the pre-reconciliation values (NAS live state)
            store = json.loads(dst.read_text(encoding="utf-8"))
            if key == "CN/board/eastmoney/BK1134":
                store["bars"]["20260224"]["low"] = "2031.22"
                store["bars"]["20260224"]["open"] = "2082.00"
            elif key == "CN/board/eastmoney/BK1037":
                store["bars"]["20260810"]["low"] = "1988.39"
                store["bars"]["20260810"]["open"] = "2024.71"
            elif key == "CN/board/eastmoney/BK0728":
                store["bars"]["20260224"]["high"] = "596.51"
                store["bars"]["20260623"]["high"] = "574.93"
                store["bars"]["20260623"]["low"] = "564.10"
            store["revisions"] = {}
            dst.write_text(json.dumps(store, ensure_ascii=False, indent=2), encoding="utf-8")

        # Create a synthetic snapshot to verify immutability
        self.snap_file = self.snapshots_dir / "snap-kline-acceptance-test.json"
        self.snap_content = b'{"snapshot_id":"snap-test-001","bars":[{"date":"2026-11-04","close":"1000.00"}]}'
        self.snap_file.write_bytes(self.snap_content)
        self.initial_snap_hash = hashlib.sha256(self.snap_content).hexdigest()

    def tearDown(self):
        self.tmp_dir.cleanup()

    def test_01_dry_run_preview(self):
        """Dry-run must accurately plan 4 revisions and make 0 disk changes."""
        hashes_before = {}
        for key in rfp.WHITELIST_TARGETS:
            safe = key.replace("/", "_")
            hashes_before[key] = hashlib.sha256((self.cache_dir / f"{safe}.json").read_bytes()).hexdigest()

        for key in rfp.WHITELIST_TARGETS:
            res = rfp.reconcile_board(key, self.origin_dir, cache_dir=self.cache_dir, apply=False)
            self.assertEqual(res["status"], "DRY_RUN_SUCCESS")
            self.assertEqual(res["revisions_count"], 0)
            if key == "CN/board/eastmoney/BK1134":
                self.assertEqual(res["revisions_needed"], 1)
            elif key == "CN/board/eastmoney/BK1037":
                self.assertEqual(res["revisions_needed"], 1)
            elif key == "CN/board/eastmoney/BK0728":
                self.assertEqual(res["revisions_needed"], 2)

        # Confirm 0 disk mutations
        for key in rfp.WHITELIST_TARGETS:
            safe = key.replace("/", "_")
            hash_after = hashlib.sha256((self.cache_dir / f"{safe}.json").read_bytes()).hexdigest()
            self.assertEqual(hashes_before[key], hash_after, f"Cache file for {key} mutated during dry-run!")

    def test_02_apply_real_four_points(self):
        """Apply mode must execute exactly 1/1/2 revisions and update price points."""
        # 1. Apply BK1134
        res1 = rfp.reconcile_board("CN/board/eastmoney/BK1134", self.origin_dir, cache_dir=self.cache_dir, apply=True)
        self.assertEqual(res1["status"], "APPLIED_SUCCESS")
        self.assertEqual(res1["revisions_count"], 1)
        self.assertEqual(res1["revised_dates"], ["20260224"])
        store1 = br.load_board_cache("CN/board/eastmoney/BK1134", cache_dir=self.cache_dir)
        self.assertEqual(store1["bars"]["20260224"]["low"], "2031.24")
        self.assertEqual(len(store1["bars"]), 500)

        # 2. Apply BK1037
        res2 = rfp.reconcile_board("CN/board/eastmoney/BK1037", self.origin_dir, cache_dir=self.cache_dir, apply=True)
        self.assertEqual(res2["status"], "APPLIED_SUCCESS")
        self.assertEqual(res2["revisions_count"], 1)
        self.assertEqual(res2["revised_dates"], ["20260810"])
        store2 = br.load_board_cache("CN/board/eastmoney/BK1037", cache_dir=self.cache_dir)
        self.assertEqual(store2["bars"]["20260810"]["low"], "1988.42")
        self.assertEqual(len(store2["bars"]), 500)

        # 3. Apply BK0728
        res3 = rfp.reconcile_board("CN/board/eastmoney/BK0728", self.origin_dir, cache_dir=self.cache_dir, apply=True)
        self.assertEqual(res3["status"], "APPLIED_SUCCESS")
        self.assertEqual(res3["revisions_count"], 2)
        self.assertEqual(res3["revised_dates"], ["20260224", "20260623"])
        store3 = br.load_board_cache("CN/board/eastmoney/BK0728", cache_dir=self.cache_dir)
        self.assertEqual(store3["bars"]["20260224"]["high"], "596.50")
        self.assertEqual(store3["bars"]["20260623"]["high"], "574.92")
        self.assertEqual(len(store3["bars"]), 500)

    def test_03_decimal_equivalence_no_spurious_revisions(self):
        """Decimal equivalence must suppress spurious revisions from string representations."""
        # BK1134 20260224: cache open is "2082.00", origin kline is "2082.00" or "2082"
        # BK0728 20260623: cache low is "564.10", origin kline is "564.10" or "564.1"
        rfp.reconcile_board("CN/board/eastmoney/BK1134", self.origin_dir, cache_dir=self.cache_dir, apply=True)
        rfp.reconcile_board("CN/board/eastmoney/BK0728", self.origin_dir, cache_dir=self.cache_dir, apply=True)

        store_1134 = br.load_board_cache("CN/board/eastmoney/BK1134", cache_dir=self.cache_dir)
        revs_1134 = store_1134.get("revisions", {}).get("20260224", [])
        self.assertEqual(len(revs_1134), 1)
        # Verify only low changed; open remained identical in 'from' and 'to'
        self.assertEqual(revs_1134[0]["from"]["low"], "2031.22")
        self.assertEqual(revs_1134[0]["to"]["low"], "2031.24")
        self.assertEqual(revs_1134[0]["from"]["open"], revs_1134[0]["to"]["open"])

        store_0728 = br.load_board_cache("CN/board/eastmoney/BK0728", cache_dir=self.cache_dir)
        revs_0728_jun = store_0728.get("revisions", {}).get("20260623", [])
        self.assertEqual(len(revs_0728_jun), 1)
        self.assertEqual(revs_0728_jun[0]["from"]["high"], "574.93")
        self.assertEqual(revs_0728_jun[0]["to"]["high"], "574.92")
        self.assertEqual(revs_0728_jun[0]["from"]["low"], revs_0728_jun[0]["to"]["low"])

    def test_04_idempotency_second_run(self):
        """Running apply a second time must produce exactly 0 revisions."""
        # First run
        for key in rfp.WHITELIST_TARGETS:
            rfp.reconcile_board(key, self.origin_dir, cache_dir=self.cache_dir, apply=True)

        # Snapshot hashes after first run
        hashes_after_first = {}
        for key in rfp.WHITELIST_TARGETS:
            safe = key.replace("/", "_")
            hashes_after_first[key] = hashlib.sha256((self.cache_dir / f"{safe}.json").read_bytes()).hexdigest()

        # Second run
        for key in rfp.WHITELIST_TARGETS:
            res = rfp.reconcile_board(key, self.origin_dir, cache_dir=self.cache_dir, apply=True)
            self.assertEqual(res["status"], "APPLIED_SUCCESS")
            self.assertEqual(res["revisions_count"], 0)
            self.assertEqual(res["revised_dates"], [])
            if key == "CN/board/eastmoney/BK0728":
                self.assertEqual(res["already_reconciled"], 2)
            else:
                self.assertEqual(res["already_reconciled"], 1)

    def test_05_old_value_mismatch_rejection(self):
        """If on-disk cache has an unexpected value, reconciliation must abort immediately."""
        safe = "CN_board_eastmoney_BK1134"
        p = self.cache_dir / f"{safe}.json"
        data = json.loads(p.read_text(encoding="utf-8"))
        data["bars"]["20260224"]["low"] = "9999.99"  # Unexpected corrupted value
        p.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

        with self.assertRaises(rfp.PreconditionError) as ctx:
            rfp.reconcile_board("CN/board/eastmoney/BK1134", self.origin_dir, cache_dir=self.cache_dir, apply=True)
        self.assertIn("Precondition failed", str(ctx.exception))

        # Check file was NOT modified to 2031.24
        re_data = json.loads(p.read_text(encoding="utf-8"))
        self.assertEqual(re_data["bars"]["20260224"]["low"], "9999.99")

    def test_06_unrelated_dates_and_metadata_preserved(self):
        """All 499 / 499 / 498 unrelated bars must be completely untouched."""
        # Read before state for BK1134
        store_before = json.loads((self.cache_dir / "CN_board_eastmoney_BK1134.json").read_text(encoding="utf-8"))
        rfp.reconcile_board("CN/board/eastmoney/BK1134", self.origin_dir, cache_dir=self.cache_dir, apply=True)
        store_after = json.loads((self.cache_dir / "CN_board_eastmoney_BK1134.json").read_text(encoding="utf-8"))

        for d, bar in store_before["bars"].items():
            if d == "20260224":
                continue
            self.assertEqual(bar, store_after["bars"][d], f"Unrelated date {d} modified!")
        self.assertEqual(len(store_after["bars"]), 500)

    def test_07_snapshot_bytes_immutability(self):
        """Snapshots must remain 100% byte-for-byte immutable throughout reconciliation."""
        for key in rfp.WHITELIST_TARGETS:
            rfp.reconcile_board(key, self.origin_dir, cache_dir=self.cache_dir, apply=True)

        current_snap_hash = hashlib.sha256(self.snap_file.read_bytes()).hexdigest()
        self.assertEqual(self.initial_snap_hash, current_snap_hash, "Snapshot file corrupted during reconciliation!")

    def test_08_write_failure_atomic_recovery(self):
        """Simulated API failure must trigger rollback from backup file."""
        key = "CN/board/eastmoney/BK1134"
        safe = key.replace("/", "_")
        cache_path = self.cache_dir / f"{safe}.json"
        hash_before = hashlib.sha256(cache_path.read_bytes()).hexdigest()

        # Monkeypatch reconcile_series_cache to simulate failure
        original_fn = br.reconcile_series_cache
        try:
            def failing_reconcile(*args, **kwargs):
                return {"status": "failed", "error": "Simulated disk IO error"}

            br.reconcile_series_cache = failing_reconcile

            with self.assertRaises(RuntimeError) as ctx:
                rfp.reconcile_board(key, self.origin_dir, cache_dir=self.cache_dir, apply=True)
            self.assertIn("Simulated disk IO error", str(ctx.exception))

            # Verify file was rolled back
            hash_after = hashlib.sha256(cache_path.read_bytes()).hexdigest()
            self.assertEqual(hash_before, hash_after, "Rollback failed to restore original file!")
        finally:
            br.reconcile_series_cache = original_fn


if __name__ == "__main__":
    unittest.main()
