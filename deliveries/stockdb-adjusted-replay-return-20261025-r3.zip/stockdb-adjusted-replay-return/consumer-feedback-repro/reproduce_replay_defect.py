#!/usr/bin/env python3
"""Offline recorded counterexample; exit 0 means reproduced, not NAS accepted."""
import json
import hashlib
import importlib.util
from pathlib import Path

ROOT=Path(__file__).resolve().parent
spec=importlib.util.spec_from_file_location('frozen_replay_contract',ROOT/'contract/validate_contract.py')
wire=importlib.util.module_from_spec(spec);spec.loader.exec_module(wire)


def main():
    m=json.loads((ROOT/'MANIFEST.sha256.json').read_text())
    for name,h in m['files'].items():
        p=(ROOT/name).resolve();assert p.is_relative_to(ROOT) and p.is_file()
        assert hashlib.sha256(p.read_bytes()).hexdigest()==h,name
    result=[]
    for mode in ('qfq','hfq'):
        record=json.loads((ROOT/(mode+'.json')).read_text())
        wire.validate(record['factor'],'FactorResponse')
        wire.validate(record['original'],'KlineResponse')
        assert record['original']['query']['fq']==record['replay']['query']['fq']==mode
        assert record['same_data_hash'] is True
        assert all(meta['adjustment']['mode']=='none' for meta in record['replay']['meta'].values())
        try:wire.validate(record['replay'],'KlineResponse')
        except Exception as exc:
            result.append({'mode':mode,'expected_validation_failure':type(exc).__name__,
                           'original_adjustment':record['expected_adjustment'],
                           'replay_adjustment':record['actual_adjustment']})
        else:raise AssertionError('Invalid adjusted replay unexpectedly accepted')
    print(json.dumps({'verification':'EXPECTED_REPLAY_DEFECT_REPRODUCED','acceptance':'BLOCKED',
                      'counterexamples':result,'note':'Do not infer acceptance from identical data hashes.'},
                     ensure_ascii=False,indent=2))


if __name__=='__main__':main()
