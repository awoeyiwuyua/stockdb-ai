# 给NAS维护Agent：0.14.1复权A快照重放补修

## 任务

本项目开始真实隔离编排后，新发现A快照重放的元数据违约。请先核对实际部署身份，
使用包内最小请求复现，再修补真实服务；保留已有修改、原合同及此前反例。
本任务只修服务实现和回归，不修改消费方校验器、合同或当前已启用的股票/ETF主源。

合同仍为stockdb-market-v3/3.0.0及research-extension/1.0.0；不新增接口或参数。
已知部署：stockdb-native 0.14.1，build src+0.14.1+55c8e04。

## 实际反例

证券XSHE/equity/exchange/000001，20261020—20261023，frequency=1d、limit=0。
两条独立路径：qfq锚20261023，hfq锚20261020。

1. get_adjust_factors取得F。
2. get_kline携带fq、adjustment_anchor、factor_snapshot_id=F取得A。
3. 相同请求再追加snapshot_id=A重放。

首次响应的meta.adjustment正确：mode=qfq/hfq、anchor_date=请求锚点、factor_snapshot_id=F、algorithm=affine-v1。
重放响应status仍complete、query仍为复权请求，但meta变成：

```json
{"mode":"none","anchor_date":null,"factor_snapshot_id":null,"algorithm":null}
```

data_hash相同不代表响应合格：它只覆盖data，没有覆盖meta。
消费方按原合同报`get_kline: invalid v3 response: adjustment mismatch`，拒绝整批隔离发布。
完整500日6证券链也在qfq的A重放步骤复现；原始5000条子范围可正常隔离完成。

包内qfq.json/hfq.json含实际F、首次A、重放A、完整原请求、expected/actual元数据及build。
使用你的既有MCP调用器重放这些公开arguments；快照有保留期，过期后须先新建F和A再复验。

## 已定位的修补方向

回传源码中market_v3_research.py::_adjusted_from_snapshot调用v3._kline_from_snapshot后，
只补回research_extensions，没有把meta.adjustment恢复为捕获的复权语义。
首次计算路径有对应覆盖逻辑，重放路径遗漏；请结合当前源码核实，不机械套旧路径。

要求：

1. 校验snapshot的kind及捕获时fq/anchor/F，不允许修改请求参数扩张或偷换快照。
2. 对合法A重放，用捕获的mode/anchor/F/algorithm构造每证券meta.adjustment，保持与query及原A一致。
3. 原始R和普通none快照仍为none/null，不全局污染核心未复权分支。
4. 保留R/A价格series描述、原始来源/捕获时间、单位、数据/因子版本，不重新抓上游替换旧值。
5. 不在客户端按请求“猜补”，不删断言、不只检查data_hash、不把完整复权批次改成raw-only后宣称复权完成。

## 必验矩阵

- qfq/hfq，股票/ETF，单票/单元素/混合批量。
- 首次A与同范围A重放：完整schema及跨字段校验、meta、data、source_catalog、research扩展一致。
- A子日期/子证券/fields投影重放仍保留mode、锚点、F及算法；锚点位于子区间外时不重置。
- 正数limit导致partial时复权语义仍正确，不能退回none。
- 错fq/anchor/F、互传R/F/A、范围扩张继续明确拒绝。
- 正常重启后A重放仍通过完整合同校验，不仅比较hash或“可读”。
- R/F/A原重建器在4日及500日、沪深股票/ETF上通过；成交量额不复权。
- 当前核心股票/ETFnone、指数price-only与原有schema/旧版兼容回归保持通过。
- 用本项目同一冻结校验器校验**首次和重放两份响应**，不只调用内部recompute。

## 回传

真实ZIP，含新版本/build/commit、最小源码diff、工具schema、两模式首次及重放请求响应、
逐条测试/运行输出、部署/重启证据和SHA256 manifest。旧失败原样保留，新修补生成新build及新证据。
若板块等其他项仍受阻，继续独立报告；本补修不要求把它们伪装成通过，也不重新引入5日观察前置条件。

补修包中的离线复现器退出0表示“旧反例已复现”，不表示服务验收通过。
NAS修复后交付新样本，再由本项目实际执行stockdb-research全模式完成隔离联合复验。
