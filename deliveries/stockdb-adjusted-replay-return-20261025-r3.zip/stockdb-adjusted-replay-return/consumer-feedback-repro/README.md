# NAS复权重放补修

先读FEEDBACK.md。原合同保持不变。

使用所在环境管理的Python（需jsonschema>=4.25,<5）：

```bash
uv run python reproduce_replay_defect.py
```

纯离线反例复现，退出0表示旧缺陷复现，不代表服务通过。
qfq.json/hfq.json包含公开完整请求、F、首次A及重放A。
在实际NAS用既有调用器按F→A→重放A顺序重建，旧snapshot到期后不要只重放旧ID。
修复后回传新build和新证据；不修改消费方校验器、不根据query伪补返回元数据。
