# 上游源探测（0.14.2 第三轮窗口，2026-10-25）

- 东财 push2his：仍不可达（BK BLOCKED 维持；消费方独立复测一致）。
- 腾讯 ifzq：可达（本轮 I08 跨提供者对照成立）。
- 新浪：可用。引擎：正常（20261023）。
- 历史探测细节见 r2 包 logs/upstream-probes.md（存档于 consumer-feedback-repro 同级或第二轮 zip）。
