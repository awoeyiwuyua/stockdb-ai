# 复现命令

```bash
# 反例复现（0.14.1 旧缺陷；0.14.2 上该脚本对服务重放将失败=已修复，
# 但离线记录反例仍退出 0 表示旧反例被记录）
uv run python reproduce_replay_defect.py   # 反馈包原件

# 端到端重放验证（0.14.2；冻结校验器逐份校验首次+重放）
cd stockdb-ai/interfaces/mcp && uv run --project ../../.. python \
    ../../../.tmp-fb3-20261025/replay_verify.py out.json

# 单测（148 例，含重放矩阵）
cd stockdb-ai && uv run --project .. python -m unittest \
    interfaces.mcp.test_market_v3 interfaces.mcp.test_market_v3_research

# live/nas 验收
cd stockdb-ai/interfaces/mcp && STOCKDB_HOST=192.168.50.146 \
    uv run --project ../../.. python acceptance_v3_research.py --mode live   # / --mode nas --url http://192.168.50.146:8081/mcp

# 重启持久化 + 冻结校验器验重放（会 docker restart 生产容器）
cd stockdb-ai/interfaces/mcp && uv run --project ../../.. python \
    restart_persistence_check.py out.json
```
