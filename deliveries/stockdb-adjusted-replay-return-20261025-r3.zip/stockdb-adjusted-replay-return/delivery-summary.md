# delivery-summary（第三轮 r3）— A 快照重放 meta.adjustment 补修

服务端交付：**0.14.2**，部署 build `src+0.14.2+30a0bbb`（commit 30a0bbb，镜像
stockdb-ai:0.14.2，端点 http://192.168.50.146:8081/mcp）。反馈包
`2026-10-25-stockdb-adjusted-replay-feedback` 的反例已修复；合同
stockdb-market-v3/3.0.0 与 research-extension/1.0.0 零变更（反馈包 contract
四文件与本仓库逐字节一致已核验）；不新增接口/参数；股票/ETF 主源未动。

## 修复内容（最小 diff，见 source/diff-full.patch）

- `_adjusted_from_snapshot`：重放路径此前只补回 research extensions，
  **遗漏恢复 meta.adjustment**（首次计算路径有覆盖、重放路径没有——与消费方
  定位一致）。现用**捕获时 payload** 的 mode/anchor/F/algorithm（affine-v1）
  恢复每个有复权行证券的 meta.adjustment；语义来自快照，不按请求猜补；
  错误/空行证券与首次一致保持 none；R/普通 none 快照不经该路径，核心未复权
  分支不受污染。
- 附带：fq≠捕获值的 A 快照重放错误消息精确化（指明须携带相同
  fq/adjustment_anchor/factor_snapshot_id，附 captured/requested fq）。

## 必验矩阵结果（replay-verify/replay-verify.json + 单测 148 例全绿）

- **qfq/hfq × 股票/ETF × 单票/单元素/混合批量**：8 用例全 PASS——首次与重放
  均过**冻结扩展校验器**（wire.validate KlineResponse/FactorResponse 逐份），
  meta.adjustment 首次==重放（mode/anchor/F/algorithm）、data 相等、
  source_catalog 相等。
- **子日期重放**（锚点 20261023 在子区间 20261021-22 之外，不重置）、
  **子证券**、**fields 投影**：复权语义保留 + 冻结校验器通过。
- **limit 正数 partial**：复权语义不退回 none（单测锁定）。
- **负例**：错 fq / R 当 A 重放（none+snapshot_id=A）/ fq=none 打 A 快照
  → 全部 SNAPSHOT_SCOPE_MISMATCH（replay-verify negatives.all_refused=true）。
- **重启**：docker restart 前后 F/R/A hash/data/元数据/retrieved_at 一致，
  且**冻结校验器接受重启后 A 重放响应**（a15-restart-persistence.json
  frozen_validator_accepts_replay=true, all_ok=true）。
- **reconstruct**：R/F/A 重建器 4 日（单测）与 500 日（nas A11 证据）
  沪深股票/ETF 通过；量额不复权（A10）。
- **核心回归**：基线三模式 0 FAIL（stub 17/nas 4）；核心 none、指数
  price-only、旧版兼容不变。

## 验收计数（acceptance-report.json，56 case）

{"BLOCKED": 2, "FAIL": 1, "NOT_RUN": 9, "PASS": 44}

- FAIL 仅 H01 板块分项（东财 push2his 第三轮窗口仍不可达，BLOCKED 如实维持，
  与消费方独立复测一致）；I03/I07/H04 BLOCKED；J 组 NOT_RUN
  （consumer_workspace_required）。本补修不伪装这些项为通过。

## 旧反例保留

consumer-feedback-repro/ 原样保留反馈包 FEEDBACK/README/复现器/qfq.json/
hfq.json（0.14.1 反例）；r2 包证据（两轮部署事实）在 deployment/r2-*.json。
新证据全部来自 0.14.2 新 build。
