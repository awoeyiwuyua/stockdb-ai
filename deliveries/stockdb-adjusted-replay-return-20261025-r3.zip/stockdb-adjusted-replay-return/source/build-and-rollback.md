# 构建身份与回退（0.14.2 第三轮）

- 部署 commit：**30a0bbb**（0.14.2 核心修复；runner/脚本后续 cf52cc0，服务代码与 30a0bbb 相同）
- 提交清单：
cf52cc0 fix(test): restart_persistence_check 路径修正（仓库根/冻结校验器定位）
61623b8 fix(test): 重启持久化检查加冻结校验器验重放响应（R3 矩阵）
30a0bbb fix: 0.14.2——复权 A 快照重放 meta.adjustment 补修（消费方 adjusted-replay 反馈）
0bc69fb chore: 移除 HEAD 残留的临时验收证据目录
b2088ed docs: 0.14.1 部署台账 + uv.lock 补 jsonschema 传递依赖锁
46ac611 chore: 归档整理——移除误入库的临时验收证据（144 文件）；重启持久化检查脚本入库（E07）；0.14.1 NAS 部署脚本入库
0e1386e docs: 0.14.1 第二轮验收报告刷新（stub/live/nas）
92d8209 fix(acceptance): C06 断言适配 0.14.1（指数键不别名=达标，源可达时真取数）
55c8e04 fix(acceptance): S06 慢负载断言 nas 模式 NOT_RUN（引用 live 注入证据）
48b6735 fix: 0.14.1——消费方反馈 E01-E08 修补
3fc876d docs: 0.14.0 最终构建 nas 验收报告（基线套件）
a97725d fix(acceptance): I08 证据记录实际服务提供者与同源/跨源性质
6fe4803 feat: 指数日K第四提供者（新浪 getKLineData）轮转——腾讯三主机同遭 WAF 封禁的结构性备份；series_catalog 按实际服务提供者如实记录
914e2bc docs: 0.14.0 部署台账
a536af6 fix(acceptance): 源中断时 H06/H07/I06 记录空证据不崩溃
1c998cc fix(acceptance): runner 抗上游中断（指数行空时记录证据不崩溃）
3232a2f docs: 0.14.0 CHANGELOG 条目
5ca56ea fix(acceptance): 基线执行器断言更新到 0.14.0 语义（指数身份解析/板块源错误/裸qfq拒绝/X02/X04 移交扩展执行器）——stub 17 PASS 0 FAIL
aca976b fix(deploy): ifzq 三主机轮转（NAS 容器仅无前缀主机可达）+ nas 模式 latest 注入
ed871e1 feat: 0.14.0——research-extension 1.0.0 服务端落地（A 指数/板块日K + B 因子/R/F/A + 长历史）
- 镜像 stockdb-ai:0.14.2（本机构建，GIT_COMMIT=30a0bbb，端点 build=src+0.14.2+30a0bbb 一致；registry digest 不可得如实 null，本地镜像 ID 见 deployment/nas-deployment-facts.json）
- 回退：compose image 改回 stockdb-ai:0.14.1 + src-backup/compose.yaml.bak-0.14.1（或更早 0.14.0/0.13.2 均在本地）
- ⚠️ Windows 打包必须 `git -c core.autocrlf=false archive`
