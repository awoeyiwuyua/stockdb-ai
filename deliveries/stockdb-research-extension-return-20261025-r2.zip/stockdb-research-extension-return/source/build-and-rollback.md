# 构建身份与回退（0.14.1 第二轮）

- 部署 commit：**55c8e04**（分支 market-v3-research-extension；0.14.0=48b6735/1e58fd8/aca976b/6fe4803/ed871e1，基线 0.13.2=b72d445）
- 提交清单：
92d8209 fix(acceptance): C06 断言适配 0.14.1（指数键不别名=达标，源可达时真取数）
55c8e04 fix(acceptance): S06 慢负载断言 nas 模式 NOT_RUN（引用 live 注入证据）
48b6735 fix: 0.14.1——消费方反馈 E01-E08 修补
3fc876d docs: 0.14.0 最终构建 nas 验收报告（基线套件）
a97725d fix(acceptance): I08 证据记录实际服务提供者与同源/跨源性质
6fe4803 feat: 指数日K第四提供者（新浪 getKLineData）轮转——腾讯三主机同遭 WAF 封禁的结构性备份；series_catalog 按实际服务提供者如实记录
914e2bc docs: 0.14.0 部署台账
a536af6 fix(acceptance): 源中断时 H06/H07/I06 记录空证据不崩溃
1c998cc fix(acceptance): runner 抗上游中断（指数行空时记录证据不崩溃）
3232a2f docs: 0.14.0 CHANGELOG 条目
5ca56ea fix(acceptance): 基线执行器断言更新到 0.14.0 语义（指数身份解析/板块源错误/裸qfq拒绝/X02/X04 移交扩展执行器）——stub 17 PASS 0 FAIL
aca976b fix(deploy): ifzq 三主机轮转（NAS 容器仅无前缀主机可达）+ nas 模式 latest 注入
ed871e1 feat: 0.14.0——research-extension 1.0.0 服务端落地（A 指数/板块日K + B 因子/R/F/A + 长历史）
- 镜像：stockdb-ai:0.14.1（NAS 本机构建；**registry digest 不可得，image_digest 如实 null**；本地镜像 ID 见 deployment/nas-deployment-facts.json 的 image_local_id）
- compose GIT_COMMIT=55c8e04 与端点 build=src+0.14.1+55c8e04 一致（E08-3：0.14.0 轮 compose 内嵌旧 commit 的问题已以 compose.yaml.bak-0.14.1 存档并修正）
- 回退：src-backup/src-before-0.14.0-*.tar.gz + compose.yaml.bak-*（本地镜像 0.13.2/0.14.0 均在，改 image 字段即回退）
- 端点：http://192.168.50.146:8081/mcp；引擎 :7899
- ⚠️ Windows 打包必须 `git -c core.autocrlf=false archive`（CRLF 破坏 entrypoint shebang，0.14.0 轮实证）
