# delivery-summary（第二轮）— stockdb-market-v3-research-extension 1.0.0

服务端交付：**0.14.1**，build `src+0.14.1+55c8e04`（commit 55c8e04，镜像
stockdb-ai:0.14.1，端点 http://192.168.50.146:8081/mcp）。
按消费方 FEEDBACK.md E01—E08 逐项修复/补证/如实声明；合同 1.0.0 与基线六
文件零变更；旧反例与首轮记录保留于 consumer-feedback-repro/。

## E01（P1，已修复·代码变更）

所有 v3 get_kline 成功响应——**含 R 原始快照重读、子范围读取、重启恢复、
长历史与普通 core**——现在都携带 `extensions.research_v1` 价格序列目录；
**A 的 series_catalog 改为与 R 相同的价格序列描述**（series_id/provider/
methodology 一致，复权语义由 meta.adjustment 表达）；F 保持因子序列描述。
用**未改动**的 validate_contract.py 验证 `reconstruct(R,F,A)`：qfq/hfq 两模式、
股票/ETF、长窗口、重放全部通过（单测 test_rfa_roundtrip_and_recomputation
内嵌 reconstruct 检查；部署端 nas 证据 live/a11、a13）。

## E02（P1，已修复·执行器恢复原标准）

H01 逐证券精确 ==500/==250（废除 >=498 与 per-market any() 放宽）；成熟样本
600000（引擎数据洞 6 会话，UNKNOWN gap）由 **600036（招商银行，公开成熟度
证据，500/500 完整）** 替代；600000 缺口记录保留在 h01 证据中（不改称
SUSPENDED）。板块 0/250 → **H01 对应断言如实 FAIL**，A 批部分交付，不宣称
批次全部完成。

## E03（P1，已修复·证据升级）

I08 扩为 **4 指数 ×（末 5 日 + 固定规则抽样 5 日）逐点表**
（live/i08-point-tables.json：双方原值、@2dp 舍入值、绝对差、逐点判定，
4×40=160 点）。本轮腾讯恢复服务 → **跨提供者独立对照**（服务=腾讯 ifzq，
参考=新浪 CN_MarketDataService，独立于 NAS 同一缓存）4×40 全 PASS（差值
≤0.01@2dp）。服务提供者逐响应记录（i08-external-comparison 的
serving_provider_per_series 含 series_id/source_reference/build）。

## E04（P1，已修复·独立实现与真实公式证据）

- **A04**：runner 从引擎原始事件**独立实现 cum walk 与 12 位量化
  multiplier**，与服务因子逐行精确相等（a04-independent-multiplier）；
  SDK 公式证据升级为**容器内 stock_sdk.py::_apply_fq_in_memory 原文摘录**
  （a04-derivation 内嵌摘录文本；sha256 经 SSH 从容器实测记录于部署事实）。
- **A06/A07**：事件窗口扩为 **±3 交易日**（各 7 日 28 点），独立实现逐点
  Decimal 复算与服务 A 精确相等（a06/a07-point-table）；
  **引擎 mult 公式实证**：`mult = 前一交易日 close / 事件日 pre_close`
  （000001@20260924：11.60/11.35=1.0220 ✓；002594@20250729：
  337.0/111.01=3.0358→3.036 ✓）——由引擎行情数据内部自洽推导，不经服务
  因子代码；div/give/trans 字段语义无官方文档、如实保留限制；
  **废除 0.001 因子容差**（改价格精度判据）；A07 另验证 hfq 回报连续性
  （跨事件日 hfq 比值 == 独立 cum-walk 理论比值，6 点全 PASS）；
  引擎 pre_close 事件前预调整语义（不能作连续性基准）作为限制如实记录。

## E05（P2，已修复·真实负载证据）

S06 补齐：并发 **4×500 日请求并行**（每请求 ≤30s 实测）+ **慢负载注入**
（live：单码 sleep 3s，期间 status 20 次 p95 实测）+ 负载后槽位恢复检查
（injected/live-s06-timing）。nas 端无注入接口 → 该分项 NOT_RUN 并引用
live 同代码路径证据（不冒充部署端注入结果）。

## E06（未完成范围·如实 BLOCKED）

- **7 BK 板块**：第二轮复验仍不可达（与消费方独立复测一致）。保持 BLOCKED
  + typed SOURCE_UNAVAILABLE + 状态 degraded；不用 THS 冒充（I04 PASS）。
  源恢复后逐序列重验（复验命令随包）。
- **I07**：BLOCKED（窗口内无更名/方法变化事件；结构性保证由单测锁定，
  事件驱动验证需真实窗口，可由消费方指定历史窗口联合复验）。
- **H04**：BLOCKED（窗口内无带公开证据停牌窗口；600000 缺口保持 UNKNOWN）。
  合法空机器结构由 schema+单测锁定。

## E07（P2，已修复）

A15 重启验证升级：docker restart 前后 **F/R/A 三者 data_hash、data、
series 元数据、retrieved_at 逐项一致**（deployment/
a15-restart-persistence.json：`all_ok=true`，含 r_has_research_metadata、
r_catalog_equals_a_catalog、R_catalog_same_after_restart、
source_retrieved_at_unchanged）——不再只证"可读"。

## E08（P2，已修复·打包与台账）

1. 本包为**真实 ZIP**（zipfile 写出，MANIFEST 覆盖全部文件）。
2. contract/**baseline 六文件已补齐**（内层 MANIFEST 与原校验器可在另一
   工作区直接运行：`uv run python contract/research-extension/
   validate_contract.py --report acceptance-report.json --evidence-root .`）。
3. 部署身份统一：compose GIT_COMMIT=**55c8e04** = 端点 build=
   `src+0.14.1+55c8e04`；0.14.0 轮 compose 内嵌旧 commit 的问题已在
   compose.yaml.bak-0.14.1 存档并修正（source/build-and-rollback.md 说明
   各字段对应的实际定位）。
4. **image_digest 如实 null**（本地构建不入 registry）；本地镜像身份
   （ID/创建时间）在 deployment/nas-deployment-facts.json 单独标注。
5. 报告按断言级如实状态（无为 PASS 而修改合同/删断言/降窗口；
   H01 板块分项保持 FAIL）。

## 验收计数（acceptance-report.json，56 case）

{"BLOCKED": 2, "FAIL": 1, "NOT_RUN": 9, "PASS": 44}

- live 模式：35 PASS / 1 FAIL（H01 板块分项）/ 0 其他
- nas 模式（部署端点 55c8e04）：35 PASS / 1 FAIL（同上）
- FAIL=H01 板块分项（东财源 BLOCKED 的诚实结果）；I03=BLOCKED；
  I07/H04=BLOCKED；J01—J08=NOT_RUN（consumer_workspace_required）
- 基线三模式 0 FAIL（stub 17/live 6/nas 4；C06 断言适配 0.14.1）
- 消费方旧反例：consumer-feedback-repro/ 保留原取证与 FEEDBACK 原文；
  E01 反例已被修复版本取代（新证据 live/raw-*、long-R-*、deployment/a15）

## 边界（不隐藏）

- A 批部分交付：指数 PASS（price-only）、板块 BLOCKED；H01 板块分项 FAIL。
- 指数量额 null（price-only）；量额依赖用途属消费方 J04。
- engine mult 公式由数据自洽实证；div/give/trans 字段语义无官方文档
  （限制保留）；引擎 pre_close 预调整语义已记录。
