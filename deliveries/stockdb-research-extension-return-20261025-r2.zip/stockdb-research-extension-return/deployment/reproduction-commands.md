# 复现命令（干净环境）

```bash
# 离线合同自检 + 报告校验
uv run python stockdb-ai/interfaces/mcp/contract/research-extension/validate_contract.py --self-test
uv run python stockdb-ai/interfaces/mcp/contract/research-extension/validate_contract.py --report <pkg>/acceptance-report.json --evidence-root <pkg>

# 单元/注入测试（合成数据）
cd stockdb-ai && uv run --project .. python -m unittest \
    interfaces.mcp.test_market_v3 interfaces.mcp.test_market_v3_research \
    interfaces.mcp.test_stockdb_mcp_server

# live 取证（含 E05 注入；引擎指向 NAS）
cd stockdb-ai/interfaces/mcp && STOCKDB_HOST=192.168.50.146 \
    STOCKDB_BUILD_COMMIT=55c8e04 \
    uv run --project ../../.. python acceptance_v3_research.py --mode live

# 部署端点验收
cd stockdb-ai/interfaces/mcp && STOCKDB_HOST=192.168.50.146 \
    uv run --project ../../.. python acceptance_v3_research.py --mode nas --url http://192.168.50.146:8081/mcp

# E07 重启持久化（会 docker restart 生产容器！）
python stockdb-ai/interfaces/mcp/restart_persistence_check.py out.json
（脚本已入库：commit 0bc69fb；会 docker restart 生产容器）
```
