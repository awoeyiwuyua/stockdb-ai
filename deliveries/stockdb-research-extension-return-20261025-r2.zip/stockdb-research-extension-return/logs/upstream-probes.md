# 上游源探测记录（第二轮 0.14.1 验收窗口，2026-10-25）

- **东财 push2his**：第二轮复验仍不可达（BK1138 typed SOURCE_UNAVAILABLE 与消费方独立复测一致）。7 BK 保持 BLOCKED。
- **腾讯 ifzq**：第二轮恢复可达（WAF 封禁解除）；live 轮 I08 由腾讯服务 → **跨提供者独立对照**（vs 新浪参考）成立。
- **新浪 getKLineData**：全程可用（第四提供者 + 独立参考）。
- **引擎**：正常（最新 20261023）。
- 首轮探测记录见 upstream-probes-20261025-first-round.md（腾讯 WAF 501 封禁时间线 + 东财多主机探测细节）。
