# StockDB 0.17.0 第三轮后增量修复（Round 4）交付验收报告

- **报告签署时间**：`2026-11-04T22:30:00+08:00`
- **目标收盘交易日 (T)**：`2026-11-04` (Shanghai)
- **代码基线 Commit**：`b0b6eeb1c5e22798004b3c401035780d273a65e7`
- **补丁文件**：`patch-v0.17.0-r4.patch` (SHA-256: `a8cddc180c504135260b3e2e68829caa3bff6d7fb9bbeefb8a91fcebe9292b9f`)
- **红线遵守**：严格执行“未获本轮授权不部署/重启/改卷/调度/路由，不自动提交或推送”，候选修复均在本地隔离验证与打包。

---

## 一、交付状态总表

| 维度 | 状态 | 判定依据 |
| :--- | :--- | :--- |
| **本地候选状态** | **PASS** | 38/38 板块可靠性测试（含 11 项 P0/P1 合成回归）、101/101 MCP 核心测试、59/59 Research 测试全量通过；两套冻结合同离线校验 100% PASS；补丁双向可逆无冲突。 |
| **部署状态** | **STANDBY_AWAITING_AUTHORIZATION** | 生产与 NAS 容器保持原状，无未经授权的重启、调度、卷修改或路由变更；完整补丁、SHA 与运维脚本就绪，待授权应用。 |
| **真实数据质量状态** | **AUDITED_AND_RECONCILED** | 13 板块 500 日全 OHLC 与动态 T 均连续完整；4 条同花顺收盘分歧已按盘后终结年度包权威对齐，并完整归档不可变审计修订链；2 条缺年度包板块正确标注待归档；东财 4 冲突点提供全量内容寻址存证与版本证据。 |
| **消费方资格状态** | **ELIGIBLE** | 健康探测生命周期解耦，只读被动查询杜绝冷启动互锁死锁；历史 15 快照与新 13 快照 100% 保持原值重放；东财 BK 的 provider/methodology_version 真实声明为 null，绝不造假或串换。 |

---

## 二、P0：健康探测生命周期根因分析与解耦重构

### 2.1 11/4 17:28 `probing` 死锁根因
- **根因定位**：原架构中，`HEALTH._loop` 后台探测线程只在首次调用 `HEALTH.get()` 时才会隐式懒启动；而消费端在冷启动时按标准流程先执行只读状态查询 `get_data_status_v3`，该接口调用的是 `HEALTH.peek()`。`peek()` 不会唤醒工作线程，导致 `probe_state` 永远停留在 `unstarted` / `probing`，`latest` 始终为 None，消费端拒绝发起后续行情请求，形成**状态查询与行情抓取的互锁死锁**。
- **重构方案**：
  1. **显式生命周期管理**：在 `app.py` 与 `stockdb_mcp_server.py` 服务主入口显式调用 `market_v3.HEALTH.start()`，在进程关闭时显式调用 `market_v3.HEALTH.stop(timeout=2.0)`，释放线程；
  2. **状态只读被动**：`get_data_status_v3` 及核心行情链路只调用只读 `peek()`，绝不在状态读取中隐式触网或启动工作线程；
  3. **细分状态呈现**：严格区分 `unstarted`、`probing`、`timeout`、`failed`、`ready`，并通过 `extensions.core_health_probe_v1` 暴露探测耗时、时戳与重试次数，不改核心 3.0.0 schema；
  4. **确定性回归验证**：新增 `test_p0_09_cold_start_status_polling_no_market_query`，模拟冷启动消费端只轮询状态、不发行情请求，服务确定性自动在初次探测完成后进入 `ready`。

---

## 三、P0：收盘终结确认与受控重叠巡检

### 3.1 15:03 终结性误判根因与多阶段划分
- **误判根因**：原判定仅依据“当前时钟 >= 15:00 且 open == 0”，导致 15:03 抓取的 `today.js` 盘后临时清算值被误标为 `final`；一旦写入完整 500 根 final 缓存，后续请求均命中暖缓存（零出网），不再拉取盘后年度包更新。且原 `board_backfill_cycle` 存在全局东财冷却检查，东财进入冷却即全局退出，导致同花顺完全被阻塞。
- **修复与终结性划分规则**：
  - `< 15:00`（含午休 11:39）：一律标为 `bar_state: preliminary`，`archive_status: intraday_provisional`；
  - `15:00 - 15:30`：来自 `today.js` 的数值标为 `bar_state: preliminary`，`archive_status: post_close_provisional`；
  - `> 15:30` 且缺年度包（如 881124、881181）：来自 `today.js` 的数值标为 `bar_state: final`，但明确标注 `source_evidence: today_js`，`archive_status: pending_yearly_archive`，杜绝假冒年度包确认；
  - `> 15:30` 且年度包存在：确认为 `source_evidence: yearly_archive`，`archive_status: archived`，`bar_state: final`。

### 3.2 4 条同花顺分歧对齐与审计修订
依据 `origin-full` 与 `today.js` 原响应，完成 4 条同花顺板块收盘点位对齐，并记录不可变审计修订链：
1. **885809（柔性屏）**：`2628.766` -> `2634.118`（raw_hash: `d46b5272d4a2fbd372090b12a9a619f36b890b3d67cb321f452342ebc17761d2`）
2. **886069**：`2166.388` -> `2167.907`（raw_hash: `af712c3e5c7dde4613ee51bf3888c1683e243b88b597dd8ebc2998064e2aacae`）
3. **885957**：`1867.037` -> `1870.569`（raw_hash: `1a19352a36c9dbbc722e38a07f607c1868c836b2ffcaa15277599f36974b5a4b`）
4. **886009**：`2038.776` -> `2045.142`（raw_hash: `3d863d6de1f929a68e54713948210e29e4853fb2bd078276a6825f4988219a53`）
- **两条待归档板块区分**：881124（10444.003）与 881181（3592.499）年度包暂缺 11/4，数值与 NAS 一致，明确标记为 `pending_yearly_archive`。
- **快照不可变重放**：包含旧错误值的快照（如 `snap-kline-3d9fd2e73f04` 读回 885809 close=2628.766）继续 100% 精确重放旧值；无 snapshot_id 的当前查询返回 2634.118。
- **提供者隔离**：重构 `board_backfill_cycle`，移除全局退出，东财冷却仅跳过东财序列，同花顺巡检与补采正常执行。

---

## 四、P1：东财来源版本证据与内容寻址存证

对现有 4 处东财分歧点，如实披露上游 CDN 边缘分歧，保留原件内容寻址 SHA-256，不编造上游版本号：

| 标的 | 日期 | 字段 | 先前观察值 | verified origin 值 | upstream_version_id | raw_sha256 |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| **BK1134** | 2026-02-24 | low | 2031.22 | 2031.24 | `null` (如实披露) | `4bbb6a6324fb812ed21060ec8cda5a962ec9614b5e21c6269fc13eac69fa4e94` |
| **BK1037** | 2026-08-10 | low | 1988.39 | 1988.42 | `null` (如实披露) | `ef39c3b8443c74e79df1d27b577778e73a38c70790242e7a2a70f9ec907f9f7c` |
| **BK0728** | 2026-02-24 | high | 596.51 | 596.50 | `null` (如实披露) | `ae790bb85f6a1078f17f8807943e179b8448a3c888d844f12f36188dbe3130a5` |
| **BK0728** | 2026-06-23 | high | 574.93 | 574.92 | `null` (如实披露) | `ae790bb85f6a1078f17f8807943e179b8448a3c888d844f12f36188dbe3130a5` |

- **角色与口径约束**：
  - 885809 保留正式折叠屏角色，其余 6 条 THS 保持参考角色；
  - 6 个东财 BK 板块的 `provider` 与 `methodology_version` 真实暴露为 `null`，严禁用同花顺替代东财 BK；
  - 不使用随机参数探测、不绕过限流机制，所有访问遵守 `BOARD_EM_MIN_INTERVAL_MS = 1200ms` 与指数冷却。

---

## 五、完整测试套件与证据清单

### 5.1 测试执行结果汇总
1. `test_board_reliability_v1.py`：**38/38 PASS**（17.48s）
   - 涵盖 C01-C18、C22 以及 11 项 P0/P1 合成确定性场景（11:39 午休、15:03 延迟、15:30+ 年度包变化、缺年度包后出现、已有 final 行变化、重复巡检幂等、同源冲突 CDN 分歧、并发读旧快照/发布新 current、冷启动只轮询状态、超时有界线程释放、东财冷却不阻塞 THS）。
2. `test_market_v3.py`：**101/101 PASS**（3.21s，2 skipped）
3. `test_market_v3_research.py`：**59/59 PASS**（27.55s）
4. 合同离线校验：**PASS**（基线 15 正例 + 20 反例拒绝；扩展 15 正例 + 20 反例拒绝；56 验收用例全过）。
5. 历史与新快照重放：**30/30 PASS**（15 个 Round 1 快照 + 13 个 11/4 板块快照 + 2 个权益 ETF 快照全部精确重放）。

### 5.2 交付物与 Manifest 摘要
所有证据已归档至 `evidence/` 目录并打入交付包 `stockdb-candidate-0.17.0-r4-20261104.zip`：
- `patch-v0.17.0-r4.patch`：增量补丁（SHA-256: `a8cddc180c504135260b3e2e68829caa3bff6d7fb9bbeefb8a91fcebe9292b9f`）
- `evidence/eastmoney_version_evidence.json`：东财冲突点版本与原响应 SHA-256 存证
- `evidence/revisions_audit_evidence.json`：7 系列不可变审计修订链
- `evidence/full_13_series_verification.json`：13 系列 500 日完整 OHLC 与动态 T 校验记录
- `evidence/rollback_rehearsal.json`：隔离目录回退演练通过记录
- `evidence/*.log`：单元测试与合同校验原 stdout/stderr 日志
- `acceptance-report.json`：机器可读交付验收报告
- `runbook.md`：详细运维与候选部署/回退手册
- `MANIFEST.sha256.json`：全量文件哈希清册

> [!NOTE]
> 交付包经严格合规脱敏审计，严禁且未包含任何命理、账户、持仓、密钥凭据或消费方私有修订草稿。
