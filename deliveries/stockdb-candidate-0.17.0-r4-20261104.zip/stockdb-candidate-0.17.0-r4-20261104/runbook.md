# StockDB 0.17.0 候选增量修复 Runbook (Round 4)

## 1. 架构与服务生命周期

### 1.1 健康探测生命周期（解耦与只读保证）
- **显式服务器生命周期**：健康探测线程由 `app.py`（HTTP 服务）及 `stockdb_mcp_server.py`（MCP Stdio/HTTP 模式）在应用初始化时显式调用 `market_v3.HEALTH.start()` 启动，在进程终止或 SIGTERM 时通过 `market_v3.HEALTH.stop()` 有界释放线程（超时 2.0s）。
- **只读状态读取**：`get_data_status_v3` 纯被动读取 `HEALTH.peek()`，绝不因用户状态轮询隐式启动工作线程或触发上游出网请求；`_kline_fetch_and_build` 核心行情链路同样仅调用被动 `peek()`。
- **状态细分**：
  - `unstarted`：服务尚未完成生命周期初始化；
  - `probing`：后台健康探测正在执行初次探测中；
  - `timeout`：探测依赖超时（超时时间硬限由 `_HEALTH_PROBE_TIMEOUT = 2.0s` 约束）；
  - `failed`：探测发生确定性故障；
  - `ready`：健康探测成功，暴露真实 `latest_trade_date`。
- **冷启动死锁消除**：消费方在服务冷启动后只轮询 `get_data_status` 而不发任何行情请求，状态也能确定性在初次探测完成后从 `probing` 自动转入 `ready`，彻底杜绝消费端“先查状态后发请求”导致的互锁死锁。

### 1.2 收盘终结确认与受控重叠巡检
- **盘中与清算期判定**：
  - 15:00 之前（含 11:30-13:00 午休 open=0）：一律判定为 `bar_state: preliminary`，`archive_status: intraday_provisional`；
  - 15:00-15:30 盘后清算期：来自 `today.js` 的数值仍为 provisional，标记为 `bar_state: preliminary`，`archive_status: post_close_provisional`；
  - 15:30 之后：若年度包尚未收录当日（如 881124、881181），明确标记为 `source_evidence: today_js`，`archive_status: pending_yearly_archive`，严禁用 today.js 冒充年度包确认；
  - 年度包正式收录当日后：按最高优先级确认为 `source_evidence: yearly_archive`，`archive_status: archived`，`bar_state: final`。
- **受控重叠巡检机制**：
  - 后台 Worker 按 `BOARD_OVERLAP_DAYS = 5` 巡检最近交易日；若存在 `preliminary` 或 `pending_yearly_archive`，向同花顺拉取当前年度 `{year}.js` 并执行 `reconcile_series_cache`；
  - 重复巡检严格幂等：若 OHLC 数值一致，仅幂等更新元数据，不重复追加审计修订链（`revisions_count == 0`）；
  - 出现数值修订时（如 885809 close 2628.766 -> 2634.118）：自动记录含 `from`、`to`、`provider`、`reason`、`raw_hash`、`at` 的不可变审计链，递增缓存版本；
  - **提供者隔离**：东财 WAF 冷却/熔断绝不全局阻断同花顺，THS 巡检与补采完全独立放行。

---

## 2. 配置说明 (`stockdb-ai/config.py`)

| 配置项 | 默认值 | 作用说明 |
| :--- | :--- | :--- |
| `BOARD_BACKFILL_ENABLED` | `True` | 是否启用受控后台板块补采与巡检 Worker |
| `BOARD_BACKFILL_INITIAL_DELAY_SECONDS` | `90` | Worker 启动后首次执行巡检的初始延迟秒数 |
| `BOARD_BACKFILL_INTERVAL_SECONDS` | `1200` | Worker 定期巡检间隔秒数（20 分钟） |
| `BOARD_BACKFILL_TASK_BUDGET_SECONDS` | `180` | 单轮巡检任务全局耗时硬限预算（超时自动有界退出） |
| `BOARD_OVERLAP_DAYS` | `5` | 受控重叠巡检窗口交易日天数 |
| `BOARD_WARM_CACHE_MIN_DAYS` | `500` | 暖缓存判定门槛天数（>=500 且无缺口则零出网服务） |
| `BOARD_EM_MIN_INTERVAL_MS` | `1200` | 东财接口最小礼貌间隔（毫秒） |
| `BOARD_THS_MIN_INTERVAL_MS` | `300` | 同花顺接口最小礼貌间隔（毫秒） |

---

## 3. 运维 CLI 操作指南 (`board_maintenance.py`)

### 3.1 查看当前健康与 Worker 状态
```bash
python stockdb-ai/interfaces/mcp/board_maintenance.py status
# 输出 JSON 格式：
python stockdb-ai/interfaces/mcp/board_maintenance.py status --json
```

### 3.2 离线对齐历史数据与原来源存证
```bash
# 对齐 13 板块至 verified origin-full，更新错误行并记入审计链
python stockdb-ai/interfaces/mcp/board_maintenance.py reconcile \
  --origin-dir scratch/followup_zip/origin-full \
  --start 20241015 \
  --end 20261104
```

### 3.3 手动触发后台缺口补采与重叠巡检
```bash
# 受控触发一轮补采
python stockdb-ai/interfaces/mcp/board_maintenance.py backfill
# 强制穿透风控冷却期：
python stockdb-ai/interfaces/mcp/board_maintenance.py backfill --force
```

### 3.4 缓存版本格式升级与回滚
```bash
# 预览 v1 -> v2 迁移
python stockdb-ai/interfaces/mcp/board_maintenance.py migrate-v1-to-v2
# 执行迁移
python stockdb-ai/interfaces/mcp/board_maintenance.py migrate-v1-to-v2 --apply
# 安全回滚至 v1 备份格式
python stockdb-ai/interfaces/mcp/board_maintenance.py rollback-v2-to-v1
```

---

## 4. 候选部署与回退演练指令

### 4.1 镜像与代码基线关系
- **基线 Commit**：`b0b6eeb1c5e22798004b3c401035780d273a65e7`
- **运行镜像标识**：`0.17.0 / build src+0.17.0+b0b6eeb`
- **补丁文件**：`patch-v0.17.0-r4.patch` (SHA-256: `a8cddc180c504135260b3e2e68829caa3bff6d7fb9bbeefb8a91fcebe9292b9f`)

### 4.2 候选部署步骤（待授权执行）
```bash
# 1. 预检补丁完整性与可逆性
git apply --check patch-v0.17.0-r4.patch

# 2. 应用增量修复补丁
git apply patch-v0.17.0-r4.patch

# 3. 运行本地完整回归套件验证
python -m unittest stockdb-ai/interfaces/mcp/test_board_reliability_v1.py
python -m unittest stockdb-ai/interfaces/mcp/test_market_v3.py
python -m unittest stockdb-ai/interfaces/mcp/test_market_v3_research.py

# 4. 执行收盘对齐更新当前缓存
python stockdb-ai/interfaces/mcp/board_maintenance.py reconcile --origin-dir /path/to/origin-full
```

### 4.3 应急回退步骤（秒级回滚）
```bash
# 1. 反向卸载补丁
git apply --reverse patch-v0.17.0-r4.patch

# 2. 若需回退缓存格式
python stockdb-ai/interfaces/mcp/board_maintenance.py rollback-v2-to-v1

# 3. 重启服务恢复原状
```
